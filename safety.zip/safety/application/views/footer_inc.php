        <footer>
          <div class="pull-right">
              Lokate Student   <a target="_blank" href="http://www.dunamisworld.com/">Copyright © 2016 Dunamis.</a>
          </div>
          <div class="clearfix"></div>
        </footer>
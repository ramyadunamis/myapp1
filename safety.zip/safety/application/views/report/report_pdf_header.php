<table>  <tr> <td> <font size="4pt" face="Arial"> <b>TRANSPORT REPORT &nbsp;</b></font></td></tr>
            <tr>  <td>Date:<?php echo date(  "j F Y (l)", strtotime( $this->input->get('date') ) );?>

                </td> <td></td></tr></table>
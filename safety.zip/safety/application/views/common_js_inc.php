    <!-- jQuery -->
    <script src="<?php echo base_url()."public/";?>/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url()."public/";?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()."public/";?>js/moment/moment.min.js"></script>
     <script src="<?php echo base_url();?>public/js/datepicker/daterangepicker.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url()."public/";?>build/js/custom.min.js"></script>


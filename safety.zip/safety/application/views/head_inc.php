<!-- Bootstrap -->
    <link href="<?php echo base_url()."public/";?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url()."public/";?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="<?php echo base_url()."public/";?>/build/css/custom.min.css" rel="stylesheet">   
     <!-- iCheck -->
    <link href="<?php echo base_url()."public/";?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
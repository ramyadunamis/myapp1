<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lokate Student</title>
<style type="text/css">
<!--
body {
	background-image: url(https://host.ls-dunamis.com/~safety/uploads/otp/bg-whitebrick.jpg);
}
.style1 {
	font-size: 5px
}
.style3 {font-family: Arial, Helvetica, sans-serif}
.style4 {font-size: 24px}
.style8 {font-size: 20px}
.style10 {
	font-size: 100px;
	font-weight: bold;
	color: #ed2728;
}
.style11 {
	font-size: 12px;
	color: #666666;
}
.style12 {
	font-size: 16px;
	font-weight: bold;
}
.style13 {
	font-size: 14px
}
-->
</style></head>

<body>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%"></td>
    <td width="46%"><a href="http://www.lokate.xyz/student"><img src="https://host.ls-dunamis.com/~safety/uploads/otp/logo-lokateStudent-120.png" alt="Lokate Student" width="120" height="120" /></a></td>
    <td width="46%"><div align="right"><img src="<?php echo base_url()."uploads/logo_image/logo-GIIS-120.png";?>" alt="Lokate Student" width="120" height="120" /></div></td>
    <td width="4%"></td>
  </tr>
</table>
<br />

<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#017889">
  <tr>
    <td><div align="center" class="style1">&nbsp; </div></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF"><div align="center" class="style2">&nbsp; 
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="3%">&nbsp;</td>
    <td width="94%"><br />
      <p class="style3 style8">Thank You for registering with Lokate Student App for </p>
      <p class="style4 style3"><strong>Global Indian International School, Abu Dhabi. </strong></p>
      <p class="style3 style13">Through this app you will be able to receive notification of your child's entry &amp; exit into the school bus. The application will also provide LIVE movement of the bus on a map.</p>
      <p class="style3 style8"><span class="style12">Given below is your PASSWORD:</span><br />
        <span class="style10"><?php echo $password; ?></span>      <br />
        <span class="style11"><strong>If you have received this email in error, please ignore it.        </strong><br />
        </span></td>
    <td width="3%">&nbsp;</td>
  </tr>
</table>

    
</td>
  </tr>
  
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#017889">
  <tr>
    <td><div align="center" class="style1">&nbsp; </div></td>
  </tr>
</table>
<p align="right"><span class="style3 style4"><a href="http://www.lokate.xyz/student"><img src="https://host.ls-dunamis.com/~safety/uploads/otp/logo-LokateStudent-straight-300.png" alt="Lokate Student" width="300" height="55" /></a></span></p>
</body>
</html>
